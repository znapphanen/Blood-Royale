﻿/*  see tables */
SELECT * FROM INFORMATION_SCHEMA.TABLES  

select * FROM INFORMATION_SCHEMA.VIEWS

select * 
  from information_schema.routines 
 where routine_type = 'PROCEDURE'