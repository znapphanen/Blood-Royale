﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BR
{
    public partial class CharacterList2 : System.Web.UI.Page
    {
        public new Master master { get { return base.Master as Master; } }
        protected void Page_Load(object sender, EventArgs e)
        {
            master.showPanels(this.panelEnglandCharacterList, this.panelFranceCharacterList, this.panelGermanyCharacterList, this.panelItalyCharacterList, this.panelSpainCharacterList);
        }



        protected void changeName(object sender, GridViewCommandEventArgs e)
        {
            GridView gv = sender as GridView;

            LinkButton lb = (LinkButton)e.CommandSource;
            string textBoxValue = ((TextBox)lb.Parent.FindControl("newName")).Text; //get the name in the textbox that correlate to the button pressed
            if (textBoxValue.Equals(""))
            {
                lblError.Text = "Name cant be empty";

            }
            else
            {
                if (ExtraLib.Sql.changeName(Convert.ToInt32(e.CommandArgument.ToString()), textBoxValue)) //returns true if ok
                {
                    gv.DataBind();
                }
                else
                {
                    lblError.Text = "Name to long";
                }

            }

        }


        protected void gvEnglandCharacterList_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            string command = e.CommandName;

            switch (command)
            {
                case "ChangeName":
                    changeName(sender, e);


                    break;

            }
        }

        protected void gvFranceCharacterList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string commandArg = e.CommandArgument.ToString();
            string command = e.CommandName;

            switch (command)
            {
                case "ChangeName":

                    changeName(sender, e);

                    break;

            }
        }

        protected void gvGermanyCharacterList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string commandArg = e.CommandArgument.ToString();
            string command = e.CommandName;

            switch (command)
            {
                case "ChangeName":

                    changeName(sender, e);

                    break;

            }
        }

        protected void gvItalyCharacterList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string commandArg = e.CommandArgument.ToString();
            string command = e.CommandName;

            switch (command)
            {
                case "ChangeName":

                    changeName(sender, e);

                    break;

            }
        }

        protected void gvSpainCharacterList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string commandArg = e.CommandArgument.ToString();
            string command = e.CommandName;

            switch (command)
            {
                case "ChangeName":

                    changeName(sender, e);

                    break;

            }
        }
    }
}