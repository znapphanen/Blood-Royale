﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;

namespace BR.ExtraLib
{
    public class CustomSession
    {
        /*

        #region attributes
        private string m_SessionUsername = "UserName";
        private string m_SessionGamename = "GameName";
        private string m_GameId = "GameId";
        private string m_Turn = "Turn";
        #endregion 


        public HttpSessionState Session { get { return HttpContext.Current.Session; } }

        public string Username { get { return Session[m_SessionUsername].ToString(); } set { Session[m_SessionUsername] = value; } }
        public string Gamename { get { return Session[m_SessionGamename].ToString(); } set { Session[m_SessionGamename] = value; } }
        public int GameId { get { return Convert.ToInt32(Session[m_GameId]); } set { Session[m_GameId] = value; } }


        public CustomSession()
        {
            if (Session[m_SessionUsername] == null)
            { 
                Session.Add(m_SessionUsername,"");
            }
            if (Session[m_SessionGamename] == null)
            { 
                Session.Add(m_SessionGamename,"");
            }
            if (Session[m_GameId] == null)
            { 
                Session.Add(m_GameId,"");
            }
            if (Session[m_Turn] == null)
            { 
                Session.Add(m_Turn,"");
            }
    
        }*/
       
    }
}