﻿collataion on database must be _cs (case sensitive)

8/30/2017
If you get error TF30063 when adding in the Nuget. Connect the project in the Team Explorer.

Added ajax toolkit to the toolbox, choose item- browse.

