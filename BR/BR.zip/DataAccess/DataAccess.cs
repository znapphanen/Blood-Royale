﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


//not used
namespace BR.DataAccess
{
    

    public class DataAccess
    {
        /*
        #region Attributes
        private string m_ConnectionString;

        #endregion

        #region properties

        public string ConnectionString {

            get {

                return m_ConnectionString;
            }

            set { m_ConnectionString = value;  }


        }

        #endregion*/
    }
}